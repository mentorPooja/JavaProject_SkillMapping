package com.niit.JUnitTestCases;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.context.junit4.SpringRunner;

import com.niit.Config.ApplicationContext;
import com.niit.Model.EmployeeRegistration;
import com.niit.Model.Profile;
import com.niit.service.ProfileService;



@RunWith(SpringRunner.class)
@SpringJUnitConfig(classes = ApplicationContext.class)


public class ProfileTest {

	@Autowired
	private ProfileService profileService;
	Profile pro;

	@Before
	public void setUp() throws Exception {

		//EmployeeRegistration e1 = new EmployeeRegistration();
		//e1.setEmpId(1);
		Profile pro1 = new Profile();
		//pro1.setEmpId(e1.getEmpId());
		pro1.setProfileId(111);
		pro1.setSscMks(92.57f);
		pro1.setHscMks(89.87f);
		pro1.setGraduation(79.07f);
		pro1.setPostGraduation(79.87f);
		pro1.setGraduationStream("Computer Science");
		pro1.setPostStream("Computer Science");
		pro1.setNoOfVisits(2);
		pro1.setSkills("Core Java,Advanced Java,Hibernate,Spring");
		
		//EmployeeRegistration e2 = new EmployeeRegistration();
		//e2.setEmpId(2);
		
		Profile pro2 = new Profile();
		//pro2.setEmpId(e2.getEmpId());
		pro2.setProfileId(112);
		pro2.setSscMks(82f);
		pro2.setHscMks(81.87f);
		pro2.setGraduation(69.07f);
		pro2.setPostGraduation(87f);
		pro2.setGraduationStream("Computer Application");
		pro2.setPostStream("MCA");
		pro2.setNoOfVisits(5);
		pro2.setSkills("Core Java,Advanced Java,Hibernate");
		
		profileService.addProfile(pro1);
		profileService.addProfile(pro2);
	
		
	}
	
	@Test 
	public void testGetProfileDetails() 
	{
	 

	 int count = profileService.getProfileDetails().size();

	assertEquals("success", 2, count); 
	
	}
	


}
