package com.niit.DAO;

import java.util.List;
import com.niit.Model.Profile;

public interface ProInterface 
{
	boolean addProfile(Profile pro);

	boolean updateProfile(Profile pro);

	boolean deleteProfile(int Id);

	List<Profile> getProDetails();

	Profile getProfileById(int Id);


}
