package com.niit.service;

import java.util.List;

import javax.transaction.Transactional;

import com.niit.Model.Profile;


@Transactional
public interface ProfileService
{
	boolean addProfile(Profile pro);

	boolean updateProfilep(Profile pro);

	boolean deleteProfile(int Id);

	List<Profile> getProfileDetails();

	Profile getProfileById(int Id);


}
