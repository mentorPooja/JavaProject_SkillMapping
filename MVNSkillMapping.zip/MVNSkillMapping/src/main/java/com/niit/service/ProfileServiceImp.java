package com.niit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.DAO.ProInterface;
import com.niit.Model.Profile;

@Service
public class ProfileServiceImp implements ProfileService
{
	@Autowired
	private ProInterface proDao;

	public boolean addProfile(Profile pro) {
		if (proDao.getProfileById(pro.getProfileId()) != null) {
			return false;
		} else {
			proDao.addProfile(pro);
			return true;
		}
	}

	public boolean updateProfilep(Profile pro) {
		return proDao.updateProfile(pro);
			}

	public boolean deleteProfile(int Id) {
		if(proDao.getProfileById(Id)!=null) {	
			proDao.deleteProfile(Id);
			return true;
		}
		else {
			return false;
		}

}

	public List<Profile> getProfileDetails() {
		return proDao.getProDetails();
}

	public Profile getProfileById(int Id) {
		return proDao.getProfileById(Id);
}


}
