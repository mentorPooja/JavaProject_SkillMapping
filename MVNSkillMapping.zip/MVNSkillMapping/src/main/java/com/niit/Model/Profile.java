package com.niit.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.lang.NonNull;

import com.niit.Model.EmployeeRegistration;
public class Profile {
	

	
	
	//@NonNull
	//@OneToOne
	///@PrimaryKeyJoinColumn
	//EmployeeRegistration emp;
	
	@Id
	int profileId ;
	@NonNull
	String skills;
	@NonNull
	float hscMks,sscMks,graduation,postGraduation;
	@NonNull
	String graduationStream,postStream;
	@NonNull
	int noOfVisits;
	@NonNull
	String yearsOfExperience;
	
	public String getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(String yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	
	public float getHscMks() {
		return hscMks;
	}

	public void setHscMks(float hscMks) {
		this.hscMks = hscMks;
	}

	public float getGraduation() {
		return graduation;
	}

	public void setGraduation(float graduation) {
		this.graduation = graduation;
	}


	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public float getSscMks() {
		return sscMks;
	}

	public void setSscMks(float sscMks) {
		this.sscMks = sscMks;
	}

	public float getPostGraduation() {
		return postGraduation;
	}

	public void setPostGraduation(float postGraduation) {
		this.postGraduation = postGraduation;
	}

	/*public int getEmpId() {
		return emp.empId;
	}

	public void setEmpId(int empId) {
		emp.empId = empId;
	}*/

	public String getGraduationStream() {
		return graduationStream;
	}

	public void setGraduationStream(String graduationStream) {
		this.graduationStream = graduationStream;
	}

	public String getPostStream() {
		return postStream;
	}

	public void setPostStream(String postStream) {
		this.postStream = postStream;
	}

	public int getNoOfVisits() {
		return noOfVisits;
	}

	public void setNoOfVisits(int noOfVisits) {
		this.noOfVisits = noOfVisits;
	}


}
